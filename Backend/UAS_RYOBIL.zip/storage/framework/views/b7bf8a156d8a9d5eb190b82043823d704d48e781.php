<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Aktifkan Akun Anda, Mulai Menggunakan Ryobil!!</h2>
    <p>Selamat Datang!, <?php echo e($detail['body']); ?></p> <br>

    <a href="http://127.0.0.1:8000/api/verificate/<?php echo e($detail['idUser']); ?>"> Klik Disini Untuk Verifikasi!</a>
</body>
</html><?php /**PATH D:\XAMPP\htdocs\UAS_RYOBIL\resources\views/mail.blade.php ENDPATH**/ ?>